/** Automatically generated file. DO NOT MODIFY */
package com.rhymes.vehicletest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}