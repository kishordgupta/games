package com.rhymes.game.entity.elements.menu;

import com.rhymes.game.entity.elements.ui.Button;

public class ButtonStar extends Button {

	public ButtonStar(float x, float y, float width, float height,
			int zIndex, String imagePath) {
		super(x, y, width, height, zIndex, imagePath);

	}

}
