package com.rhymes.game.entity.elements.path.traversal;

import com.rhymes.ge.core.renderer.Point;

public class TraversePoint extends Point {
	public float angle;
	
}
