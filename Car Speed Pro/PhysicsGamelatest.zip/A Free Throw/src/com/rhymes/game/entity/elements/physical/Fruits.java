
package com.rhymes.game.entity.elements.physical;

import com.rhymes.ge.core.entity.elements.ElementBase;
import com.rhymes.ge.pw.assets.AssetPack;


public class Fruits extends ElementBase {


	public Fruits() {
		// TODO Auto-generated constructor stub
	}


	public Fruits(float x, float y, float width, float height, int zIndex) {
		super(x, y, width, height, zIndex);
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public void init() {
		// TODO Auto-generated method stub

	}


	@Override
	public void step(long stepTime) {
		// TODO Auto-generated method stub
		super.step(stepTime);
	}


	@Override
	public void getAssets(AssetPack assetPack) {
		// TODO Auto-generated method stub

	}

}
