package com.rhymes.game.entity.elements.unsorted;

public interface ISliderEventHandler {
	public void onSlideHit();
	public void onSwitchNext();
	public void onSwitchPrev();
}
