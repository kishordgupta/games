package com.rhymes.game.interactions;

import com.rhymes.ge.core.interactions.InteractionCallbacks;

public interface InteractionTestCallbacks extends InteractionCallbacks{
	public void onTest();
}
