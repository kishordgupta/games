package com.rhymes.game.interactions.cloudInteraction;

import com.rhymes.ge.core.interactions.InteractionCallbacks;

public interface ICLeftRight extends InteractionCallbacks{
	public void onEvent(int ctl_value);

}
