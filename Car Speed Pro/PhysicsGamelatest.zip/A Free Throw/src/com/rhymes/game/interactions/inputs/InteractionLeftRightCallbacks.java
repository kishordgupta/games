package com.rhymes.game.interactions.inputs;

import com.rhymes.ge.core.interactions.InteractionCallbacks;

public interface InteractionLeftRightCallbacks extends InteractionCallbacks{
	public void onEvent(int event);
}
