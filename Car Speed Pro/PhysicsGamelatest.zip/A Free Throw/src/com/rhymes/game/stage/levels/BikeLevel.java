package com.rhymes.game.stage.levels;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.World;
import com.rhymes.game.data.AssetConstants;
import com.rhymes.game.data.Constants;
import com.rhymes.game.entity.elements.menu.ButtonSkipChance;
import com.rhymes.game.entity.elements.nonphysical.Player;
import com.rhymes.game.entity.elements.path.traversal.Rope;
import com.rhymes.game.entity.elements.physical.Ball;
import com.rhymes.game.entity.elements.physical.Ball1;
import com.rhymes.game.entity.elements.physical.Ball3;
import com.rhymes.game.entity.elements.physical.BikeCollisionListener;
import com.rhymes.game.entity.elements.physical.Car;
import com.rhymes.game.entity.elements.physical.CarSpeedPro;
import com.rhymes.game.entity.elements.physical.CollisionListener;
import com.rhymes.game.entity.elements.physical.Elevator;
import com.rhymes.game.entity.elements.physical.FruitChain;
import com.rhymes.game.entity.elements.physical.Ground;
import com.rhymes.game.entity.elements.physical.Lift;
import com.rhymes.game.entity.elements.physical.PhysicsHelper;
import com.rhymes.game.entity.elements.physical.Vehicle;
import com.rhymes.game.entity.elements.ui.ButtonPause;
import com.rhymes.game.entity.elements.ui.ButtonQuit;
import com.rhymes.game.entity.elements.ui.ButtonRestart;
import com.rhymes.game.entity.elements.ui.PhysicsBody2;
import com.rhymes.game.entity.elements.unsorted.Background;
import com.rhymes.game.interactions.inputs.InteractionTouch;
import com.rhymes.game.interactions.inputs.InteractionTouchCallbacks;
import com.rhymes.game.stage.menus.GameMenuInfo;
import com.rhymes.ge.core.data.GlobalVars;
import com.rhymes.ge.core.renderer.Point;
import com.rhymes.ge.core.stage.StageBase;
import com.rhymes.ge.pw.assets.AssetPack;
import com.rhymes.helpers.Helper;
import com.rhymes.helpers.XMLReader;

public class BikeLevel extends StageBase implements InteractionTouchCallbacks{

	private World world;
	private float ballPositionX=0*GameMenuInfo.ratio_w;
	private float ballPositionY=500*GameMenuInfo.ratio_h;
	private int count=0;
	private boolean isInGround=true;
	private Car car;
//	private Vehicle truck;
	public Ground h0;
	private Ground virtualBody;
	private BikeCollisionListener collisionListener;
	private Ground virtualEndBody;
	private String xmlPath;
	private XMLReader xMLReader;
	private Background background;
	private Vehicle vehicle;
	private Rope rope;
	private FruitChain gear;
	
	public String getXmlPath() {
		return xmlPath;
	}

	public void setXmlPath(String xmlPath) {
		this.xmlPath = xmlPath;
	}
	public boolean isInGround() {
		return isInGround;
	}

	public void setInGround(boolean isInGround) {
		this.isInGround = isInGround;
	}

	public World getWorld() {
		return world;
	}

	public void setWorld(World world) {
		this.world = world;
	}

	public Body getH0() {
//		h0.getBody()
		return h0.getBody();
	}

	public void setH0(Ground h0) {
		this.h0 = h0;
	}

	@Override
	public void loadElements() {
		xMLReader.main(AssetConstants.XMLPATH);
		world= new World(new Vector2(0,-10f), true);
		collisionListener = new BikeCollisionListener();
		world.setContactListener(collisionListener);
		collisionListener.setCollided(true);
		InteractionTouch screenTouch = new InteractionTouch();
		this.interactions.add(screenTouch);
		// TODO Auto-generated method stub
//		virtualBody = new Ground(50*GameMenuInfo.ratio_w,150*GameMenuInfo.ratio_h,
//				05*GameMenuInfo.ratio_w,10*GameMenuInfo.ratio_h,0f,AssetConstants.IMG_GROUND_2, world,false);
//		addElement(virtualBody);
		
//		 gear = new FruitChain(new Vector2(140,250), null,null , null, 1, world, true,60,25);
//		addElement(gear);
		
//		rope = new Rope(new Vector2(gear.getX()-50,gear.getY()+20), null, 20, world,true,10,05);
		rope = new Rope(new Vector2(0,0), null, 0, world,true,10f,05);
		addElement(rope);
//		addElement(new PhysicsBody2(100, -400, 400,100,  AssetConstants.PHY_BIKEMAN ,
//		AssetConstants.PHY_IMG_BIKEMAN, "bikeman", world, ((short) 1),"carbody",2, BodyType.DynamicBody));
		
		
		
//
//		background = new Background(0, 0, 480*GameMenuInfo.ratio_w, 320*GameMenuInfo.ratio_h, 1,
//				AssetConstants.IMG_BKG_LEVEL7);
//		addElement(background);
//		screenTouch.subscribe(background);
//		 car = new Car(80*GameMenuInfo.ratio_w, 300*GameMenuInfo.ratio_h,
//				45*GameMenuInfo.ratio_w,10*GameMenuInfo.ratio_h,0f,AssetConstants.IMG_CL_BKG, world,false);
//		addElement(car);
//		
		CarSpeedPro	 krac = new CarSpeedPro(200*GameMenuInfo.ratio_w, 300*GameMenuInfo.ratio_h,
		45*GameMenuInfo.ratio_w,10*GameMenuInfo.ratio_h,0f,Constants.carTypeSchoolbus, world,false);
		addElement(krac);
		
		
//		 vehicle = new Vehicle(30*GameMenuInfo.ratio_w, 300*GameMenuInfo.ratio_h,
//					45*GameMenuInfo.ratio_w,10*GameMenuInfo.ratio_h,0f,world,false);
//			addElement(vehicle);
//			
//			Vehicle vehicle2 = new Vehicle(200*GameMenuInfo.ratio_w, 250*GameMenuInfo.ratio_h,
//						45*GameMenuInfo.ratio_w,10*GameMenuInfo.ratio_h,AssetConstants.PHY_IMG_TRUCK_HEAD2,AssetConstants.PHY_IMG_TRUCK_BODY2,0f,world,false);
//				addElement(vehicle2);
//				
//				vehicle = new Vehicle(200*GameMenuInfo.ratio_w, 250*GameMenuInfo.ratio_h,
//							45*GameMenuInfo.ratio_w,10*GameMenuInfo.ratio_h,AssetConstants.PHY_IMG_TRUCK_HEAD3,AssetConstants.PHY_IMG_TRUCK_BODY3,0f,world,false);
//					addElement(vehicle);
//					screenTouch.subscribe(vehicle);	
//		screenTouch.subscribe(car);
	
//			float nextStartX = PhysicsHelper.ConvertToWorld(rope.getLastLink().getPosition().x)+rope.getWidth()/2*19;/*virtualBody.getX()+virtualBody.getWidth()+rope.getWidth()*20;*/
//			float nextStartY = rope.getY();
//			nextStartX = 100;
//			Elevator elevator = new Elevator(world,100,new Vector2(nextStartX,nextStartY), null, rope.getLastLink(), null, 20, 05, 1);
//			addElement(elevator);
			
//			virtualEndBody = new Ground(PhysicsHelper.ConvertToWorld(lift.elevator().getPosition().x)+lift.getWidth(),10*GameMenuInfo.ratio_h,
//			50*GameMenuInfo.ratio_w,5*GameMenuInfo.ratio_h,90f,AssetConstants.IMG_GROUND_2, world,false);
//	addElement(virtualEndBody);
//			Rope rope2 = new Rope(new Vector2(virtualEndBody.getOriginX(),virtualEndBody.getY()), virtualEndBody.getBody(), 10, world,false,20,05);
//			addElement(rope2);
//			
//			float nextX = PhysicsHelper.ConvertToWorld(rope2.getLastLink().getPosition().x)+rope2.getWidth()*19;/*virtualBody.getX()+virtualBody.getWidth()+rope.getWidth()*20;*/
//			float nextY = rope.getY();
			
//			Helper.println("xml reader given rope no::::;"+xMLReader.ropes.get(0)+"xml reader given rope nodes ate::::;"+xMLReader.ropes.get(0).getNodes().get(0));
//			
			Elevator elevator0 = new Elevator(world,30,new Vector2(xMLReader.ropes.get(0).getNodes().get(0).getX(),xMLReader.ropes.get(0).getNodes().get(0).getY()), null, GameMenuInfo.ratio_w*20, GameMenuInfo.ratio_h*05, 1);
			addElement(elevator0);
//			Elevator elevator1 = new Elevator(world,20,new Vector2(xMLReader.ropes.get(1).getNodes().get(0).getX(),xMLReader.ropes.get(0).getNodes().get(0).getY()), null, GameMenuInfo.ratio_w*20, GameMenuInfo.ratio_h*05, 1);
//			addElement(elevator1);
			
//			virtualBody = new Ground(100*GameMenuInfo.ratio_w,225*GameMenuInfo.ratio_h,
//					500*GameMenuInfo.ratio_w,05*GameMenuInfo.ratio_h,0f,AssetConstants.IMG_GROUND_2, world,false);
//			addElement(virtualBody);
			
//			Ball b = new Ball1(200, 400,
//					12f * GameMenuInfo.ratio_w, world, false);
//			addElement(b);
			

			
//			Lift lift = new Lift(new Vector2(PhysicsHelper.ConvertToWorld(elevator0.getLastVertex().x)+300f,PhysicsHelper.ConvertToWorld(elevator0.getLastVertex().y-04f)), null,null , null, 1, world, true,600,25);
//			addElement(lift);
			

//			virtualEndBody = new Ground(lift.getX()+lift.getWidth(),10*GameMenuInfo.ratio_h,
//					500*GameMenuInfo.ratio_w,15*GameMenuInfo.ratio_h,0f,AssetConstants.IMG_AXLE, world,false);
//			addElement(virtualEndBody);
			
			
//			Elevator elevator2 = new Elevator(world,30,new Vector2(virtualEndBody.getBody().getPosition()), null, GameMenuInfo.ratio_w*20, GameMenuInfo.ratio_h*05, 1);
//			addElement(elevator2);
//			Elevator elevator3 = new Elevator(world,10,new Vector2(elevator2.getLastVertex().x,elevator2.getLastVertex().y-2f), null, GameMenuInfo.ratio_w*20, GameMenuInfo.ratio_h*05, 1);
//			addElement(elevator3);
//			
//			Elevator elevator4 = new Elevator(world,50,new Vector2(elevator2.getLastVertex().x-2.5f,elevator2.getLastVertex().y-4.5f), null, GameMenuInfo.ratio_w*20, GameMenuInfo.ratio_h*05, 1);
//			addElement(elevator4);
			
//		Ground	virtualEndBody1 = new Ground(PhysicsHelper.ConvertToWorld(elevator4.getLastVertex().x)+elevator4.getWidth()/2*25f,PhysicsHelper.ConvertToWorld(elevator4.getLastVertex().y)*GameMenuInfo.ratio_h,
//					500*GameMenuInfo.ratio_w,10*GameMenuInfo.ratio_h,20f,AssetConstants.IMG_AXLE, world,false);
//			addElement(virtualEndBody1);
//			Rope rope2 = new Rope(new Vector2(virtualEndBody.getX(),virtualEndBody.getY()), virtualEndBody.getBody(), 20, world,false,20,05);
//			addElement(rope2);
			
//			Helper.println("rope end Position in pixel::="+nextStartX+"lift start Position::="+lift.getX());
////			float nextStartX = PhysicsHelper.ConvertToWorld(rope.getLastLink().getPosition().x);
//			float nextStartY = PhysicsHelper.ConvertToWorld(rope.getLastLink().getPosition().y);
//			

//		this.addControls();
		

			setInput();
	}


	private void setInput() {
		Gdx.input.setInputProcessor(new InputProcessor() {
			
			@Override
			public boolean touchUp(int arg0, int arg1, int arg2, int arg3) {
//				car.shallAccelarate = false;
//				vehicle.shallAccelarate = false;
				reload();
				return false;
			}
			
			@Override
			public boolean touchMoved(int arg0, int arg1) {
				return false;
			}
			
			@Override
			public boolean touchDragged(int arg0, int arg1, int arg2) {
				if(arg0 > .5f)
				{
//					reload();
				}
				return false;
			}
			
			@Override
			public boolean touchDown(int arg0, int arg1, int arg2, int arg3) {
				Helper.println("Touch Down: Arg0: " + arg0 + " Arg1: " + arg1+ " Arg0: " + arg0+ " Arg0: " + arg0);
				
//				gear.transferSecondWheel();
//				rope.setropeJoint();
				return false;
//				if(arg0 < Gdx.graphics.getWidth()/3f)
//				{
////					car.accelarateVal = -0.1f;
////					car.shallAccelarate = true;
//					
//					vehicle.accelarateVal = -0.1f;
//					vehicle.shallAccelarate = true;
//				}
//				else if(arg0 > Gdx.graphics.getWidth()*2/3f)
//				{
////					car.accelarateVal = 0.1f;
////					car.shallAccelarate = true;
////					Helper.println("accelarateVal:::"+vehicle.accelarateVal);
////					  vehicle.accelarateVal = 0.1f;
////					vehicle.shallAccelarate = true;
//				
//					
//					
//				}
				
			}
			
			@Override
			public boolean scrolled(int arg0) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean keyUp(int arg0) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean keyTyped(char arg0) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean keyDown(int arg0) {
				// TODO Auto-generated method stub
				return false;
			}
		});
	}
	
	
	
	

	private void addControls() {
		InteractionTouch bTouch = new InteractionTouch();
		// this.interactions.add(bTouch);
		this.gameControlInteractions.add(bTouch);

		ButtonRestart bRestart = new ButtonRestart(0, Gdx.graphics.getHeight()
				- 35 * GameMenuInfo.ratio_h, 34 * GameMenuInfo.ratio_w,
				34 * GameMenuInfo.ratio_h, 1, AssetConstants.IMG_RELOAD,true);
		
		addElement(bRestart);
		
		
//		ButtonSkipChance bSkip = new ButtonSkipChance(10f * GameMenuInfo.ratio_w
//				, 10f * GameMenuInfo.ratio_h, 34 * GameMenuInfo.ratio_w,
//				34 * GameMenuInfo.ratio_h, 1, AssetConstants.IMG_SKIP);
		
		
//		ButtonSkipChance bSkip = new ButtonSkipChance(50 * GameMenuInfo.ratio_w
//				, 10f * GameMenuInfo.ratio_h, 34 * GameMenuInfo.ratio_w,
//				34 * GameMenuInfo.ratio_h, 1, AssetConstants.IMG_SKIP);
		
		// ButtonRestart bRestart = new ButtonRestart(100, 100, 34, 34, 1,
		// AssetConstants.IMG_RELOAD);
//		addElement(bSkip);
//		subscribeToControllingInteraction(bSkip, InteractionTouch.class);
		// this.topElements.add(bRestart);
		bTouch.subscribe(bRestart);
		subscribeToControllingInteraction(bRestart, InteractionTouch.class);
		ButtonPause bPause = new ButtonPause(32 * GameMenuInfo.ratio_w,
				Gdx.graphics.getHeight() - 35 * GameMenuInfo.ratio_h,
				34 * GameMenuInfo.ratio_w, 34 * GameMenuInfo.ratio_h, 1,
				AssetConstants.IMG_PAUSE);
		addElement(bPause);
		// this.topElements.add(bPause);
		bTouch.subscribe(bPause);
		subscribeToControllingInteraction(bPause, InteractionTouch.class);

		ButtonQuit bQuit = new ButtonQuit(64 * GameMenuInfo.ratio_w,
				Gdx.graphics.getHeight() - 35 * GameMenuInfo.ratio_h,
				34 * GameMenuInfo.ratio_w, 34 * GameMenuInfo.ratio_h, 1,
				AssetConstants.IMG_QUIT);
		addElement(bQuit);
		// this.topElements.add(bQuit);
		bTouch.subscribe(bQuit);
		subscribeToControllingInteraction(bQuit, InteractionTouch.class);

	}

	@Override
	public AssetPack getAssets(AssetPack assetPack) {
		assetPack.addTexture(AssetConstants.IMG_CL_BKG);
		assetPack.addTexture(AssetConstants.IMG_GROUND_2);
		assetPack.addTexture(AssetConstants.IMG_BALL_RUBBER);
		assetPack.addTexture(AssetConstants.PHY_IMG_CARBODY);
		assetPack.addTexture(AssetConstants.PHY_IMG_BIKEMAN);
		assetPack.addTexture(AssetConstants.PHY_IMG_LEFTAXLECONTAINER);
		assetPack.addTexture(AssetConstants.PHY_IMG_WHEEL);
		assetPack.addTexture(AssetConstants.PHY_IMG_TRUCK_BODY);
		assetPack.addTexture(AssetConstants.PHY_IMG_TRUCK_HEAD);
		assetPack.addTexture(AssetConstants.PHY_IMG_TRUCK_BODY2);
		assetPack.addTexture(AssetConstants.PHY_IMG_TRUCK_HEAD2);
		assetPack.addTexture(AssetConstants.PHY_IMG_TRUCK_BODY3);
		assetPack.addTexture(AssetConstants.PHY_IMG_TRUCK_HEAD3);
		assetPack.addTexture(AssetConstants.PHY_IMG_TRUCK_WHEEL);
		assetPack.addTexture(AssetConstants.PHY_IMG_TRUCK_FIRE);
		assetPack.addTexture(AssetConstants.PHY_IMG_KRAC_BODY);
		assetPack.addTexture(AssetConstants.PHY_IMG_KRAC_WHEEL);
		assetPack.addTexture(AssetConstants.PHY_IMG_BENGA_BODY);
		assetPack.addTexture(AssetConstants.PHY_IMG_BENGA_WHEEL);
		assetPack.addTexture(AssetConstants.PHY_IMG_HUWWER_BODY);
		assetPack.addTexture(AssetConstants.PHY_IMG_HUWWER_WHEEL);
		assetPack.addTexture(AssetConstants.PHY_IMG_MILITARY_BODY);
		assetPack.addTexture(AssetConstants.PHY_IMG_MILITARY_WHEEL);
		assetPack.addTexture(AssetConstants.PHY_IMG_POLICE_BODY);
		assetPack.addTexture(AssetConstants.PHY_IMG_POLICE_WHEEL);
		assetPack.addTexture(AssetConstants.PHY_IMG_SCHOOLBUS_BODY);
		assetPack.addTexture(AssetConstants.PHY_IMG_SCHOOLBUS_WHEEL);
		assetPack.addTexture(AssetConstants.PHY_IMG_SUPER_BODY);
		assetPack.addTexture(AssetConstants.PHY_IMG_SUPER_WHEEL);
		
//		return null;
		return assetPack;
	}

	@Override
	public void tick(long stepTime) {
		float dt= Gdx.graphics.getDeltaTime()+100;
		// TODO Auto-generated method stub
		
		if(!isInGround)
		{
//			car.destroyJoints();
			this.setInGround(true);
//			reload();
		}
		else return;

	}

	@Override
	public void onTouch(Point hitPoint) {
		// TODO Auto-generated method stub
//		car.setMotorSpeed(.5f);
		vehicle.setMotorSpeed(.5f);
	}

}


