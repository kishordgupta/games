package com.rhymes.ge.core.data;

import com.rhymes.ge.core.controller.GEController;

public class GlobalVars {
	public static GEController ge;
}
