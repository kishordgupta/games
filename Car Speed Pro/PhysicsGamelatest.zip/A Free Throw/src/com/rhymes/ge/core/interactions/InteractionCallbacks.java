package com.rhymes.ge.core.interactions;

import com.rhymes.ge.core.renderer.Point;

public interface InteractionCallbacks {
}
