package com.rhymes.ge.core.stage.level;

public class GameState {
	public static final int PLAYING = 0;
	public static final int  PAUSED= 1;
	public static final int  OVER= 2;
	public static final int  RELOADING = 3;
	public static final int LOADING = 4;
	public static final int FINISHED = 5;
}
