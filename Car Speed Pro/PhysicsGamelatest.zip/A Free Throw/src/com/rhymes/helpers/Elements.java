package com.rhymes.helpers;

public class Elements {
	 public int ElementRopeID;
     public float ElementRopeDistance;
     public String elementName;
     
     public Elements()
     {
         ElementRopeID = 0;
         ElementRopeDistance = 0f;
         elementName = "";
     }
}
