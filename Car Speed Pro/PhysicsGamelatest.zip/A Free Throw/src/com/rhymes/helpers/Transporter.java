package com.rhymes.helpers;

public class Transporter {
	public int TransporterInitRopeID;
    public float TransporterInitRopeDistance;
    public int TransporterDestRopeID;
    public float TransporterDestRopeDistance;
    
    public Transporter()
    {
        TransporterInitRopeID = 1000;
        TransporterInitRopeDistance = 5000f;
        TransporterDestRopeID = 1000;
        TransporterDestRopeDistance = 5000f;
    }


}
