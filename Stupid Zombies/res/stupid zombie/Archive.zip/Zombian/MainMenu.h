//
//  MainMenu.h
//  Ancient Bullet War
//
//  Created by TheAppGuruz . on 15/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@interface MainMenu : CCLayer{
    
}
+(CCScene *) scene;

-(void)addMenu;
-(void)goNext:(id)sender;

@end
