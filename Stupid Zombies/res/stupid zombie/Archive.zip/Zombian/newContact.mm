//
//  newContact.m
//  Zombian
//
//  Created by TheAppGuruz . on 17/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "newContact.h"
#import "cocos2d.h"
#import "HelloWorldLayer.h"
#import "Bullet.h"
#import "AppDelegate.h"


void newContact::BeginContact(b2Contact* contact)
{
    //NSLog(@"Called");
    b2Body* bodyA = contact->GetFixtureA()->GetBody();
    b2Body* bodyB = contact->GetFixtureB()->GetBody();
    
    CCSprite* spriteA = (CCSprite*)bodyA->GetUserData();
    CCSprite* spriteB = (CCSprite*)bodyB->GetUserData();
    
    if (spriteA != NULL && spriteB != NULL)
    {

        if((spriteA.tag == 8 && spriteB.tag == 2) || (spriteA.tag == 2 && spriteB.tag == 8))
        {
            HelloWorldLayer *ll = (HelloWorldLayer *)l;
            CGPoint pos = spriteA.position;
            Zombies *z = (Zombies *)spriteA.userData;
            if(spriteB.tag == 2)
            {
                z = (Zombies *)spriteB.userData;
                pos = spriteB.position;
            }
            if([z setDied])
            {
                ll.currentScore += 1000;
                [ll showScoreLableAt:pos :1000];
            }
        }
    }
}
void newContact::EndContact(b2Contact* contact)
{
    b2Body* bodyA = contact->GetFixtureA()->GetBody();
    b2Body* bodyB = contact->GetFixtureB()->GetBody();
    
    CCSprite* spriteA = (CCSprite*)bodyA->GetUserData();
    CCSprite* spriteB = (CCSprite*)bodyB->GetUserData();
    
    if(spriteB != NULL && spriteB.tag == 5)
    {
        Bullet *b = (Bullet *)spriteB.userData;
        b.count--;
        
        [AppDelegate PlaySound:@"bullet-sound"];

    }
    
    if (spriteA != NULL && spriteB != NULL)
    {
        /*HelloWorldLayer *ll = (HelloWorldLayer *)l;
        for(int i=0;i<ll.AllZombies.count;i++)
        {
            CGPoint pos = spriteA.position;
            Zombies *z = [ll.AllZombies objectAtIndex:i];
            if(spriteA.userData == z && spriteB.tag == 5 && bodyA == z.HEAD)
            {
                z.isHead = false;
                z.isLeg = false;
                z.isHand = false;
                if([z setDied])
                {
                    ll.currentScore += 2000;
                    [ll showScoreLableAt:pos :2000];
                }
            }
        }*/
        
    }
    
    if(spriteB != NULL && spriteB.tag == 5 && spriteA.tag == 8)
    {
        Bullet *b = (Bullet *)spriteB.userData;
        b.count = 0;
    }
}
void newContact::PreSolve(b2Contact* contact, const b2Manifold* oldManifold)
{
    b2Body* bodyA = contact->GetFixtureA()->GetBody();
    b2Body* bodyB = contact->GetFixtureB()->GetBody();
    
    CCSprite* spriteA = (CCSprite*)bodyA->GetUserData();
    CCSprite* spriteB = (CCSprite*)bodyB->GetUserData();

    
    if (spriteA != NULL && spriteB != NULL)
    {
                
        
    }
    

} 

void newContact::PostSolve(b2Contact* contact, const b2ContactImpulse* impulse)
{
    b2Body* bodyA = contact->GetFixtureA()->GetBody();
    b2Body* bodyB = contact->GetFixtureB()->GetBody();
    
    CCSprite* spriteA = (CCSprite*)bodyA->GetUserData();
    CCSprite* spriteB = (CCSprite*)bodyB->GetUserData();
    
    if (spriteA != NULL && spriteB != NULL)
    {
        HelloWorldLayer *ll = (HelloWorldLayer *)l;
        
        for(int i=0;i<ll.AllZombies.count;i++)
        {
            CGPoint pos = spriteA.position;
            Zombies *z = [ll.AllZombies objectAtIndex:i];
            if(spriteA.userData == z && spriteB.tag == 5 && bodyA == z.HEAD)
            {
                z.isHead = false;
                z.isLeg = false;
                z.isHand = false;
                if([z setDied])
                {
                    ll.currentScore += 2000;
                    [ll showScoreLableAt:pos :2000];
                }
            }
        }
        
        if(spriteA.tag == 2 && spriteB.tag == 5)
        {
            CGPoint pos = spriteA.position;
            Zombies *z = (Zombies *)spriteA.userData;
            if([z setDied])
            {
                ll.currentScore += 1000;
                [ll showScoreLableAt:pos :1000];
            }
        
        }
    } 
}






